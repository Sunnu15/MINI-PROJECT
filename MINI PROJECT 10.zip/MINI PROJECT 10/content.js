// Function to show the popup without duplicates
function showPopup(message) {
    // Create a unique identifier for the message
    let messageId = message.replace(/\s+/g, '-').toLowerCase();
    let existingPopup = document.getElementById(`roachMotelPopup-${messageId}`);

    // If the popup for this message already exists, do nothing
    if (existingPopup) {
        return;
    }

    // Create the popup
    let popup = document.createElement('div');
    popup.id = `roachMotelPopup-${messageId}`;
    popup.className = 'roachMotelPopup';
    popup.style.position = 'fixed';
    popup.style.bottom = `${20 + document.querySelectorAll('.roachMotelPopup').length * 120}px`; // Adjust position for multiple popups
    popup.style.right = '20px';
    popup.style.width = '300px';
    popup.style.backgroundColor = '#f8d7da';
    popup.style.color = '#721c24';
    popup.style.padding = '20px';
    popup.style.borderRadius = '5px';
    popup.style.boxShadow = '0px 0px 10px rgba(0, 0, 0, 0.1)';
    popup.style.zIndex = '10000';
    popup.innerHTML = `
        <p>${message}</p>
        <button class="closePopup" style="background-color: #f5c6cb; border: none; padding: 5px 10px; cursor: pointer;">Close</button>
    `;
    document.body.appendChild(popup);

    // Close the popup and update positions
    popup.querySelector('.closePopup').addEventListener('click', function() {
        popup.remove();
        updatePopupPositions();
    });
}

// Function to update the positions of all active popups
function updatePopupPositions() {
    const popups = document.querySelectorAll('.roachMotelPopup');
    popups.forEach((popup, index) => {
        popup.style.bottom = `${20 + index * 120}px`;
    });
}

// Function to detect Roach Motel patterns
function detectRoachMotel() {
    // Subscription traps
    const subscribeButtons = document.querySelectorAll('button, a');
    subscribeButtons.forEach(button => {
        let buttonText = button.textContent.toLowerCase();
        if (/subscribe|sign up|start trial|join/i.test(buttonText)) {
            button.addEventListener('click', () => {
                showPopup('Subscription Trap Detected: Hidden fees or auto-renewal might apply.');
            });
        }
    });

    // Hidden fees
    const priceElements = document.querySelectorAll('.total-price, .final-price, .price-summary, .pricing, .price');
    priceElements.forEach(priceElement => {
        let priceText = priceElement.textContent;
        if (/fees|charges|taxes/i.test(priceText)) {
            showPopup('Hidden Charges Detected: Additional fees might be included.');
        }
    });

    // Free trials that lead to automatic conversion
    const freeTrialButtons = document.querySelectorAll('button, a');
    freeTrialButtons.forEach(button => {
        let buttonText = button.textContent.toLowerCase();
        if (/free trial|buy plan|get started for free|start free|try for free/i.test(buttonText)) {
            button.addEventListener('click', () => {
                showPopup('Free Trial Trap Detected: This may automatically convert to a paid subscription.');
            });
        }
    });

    // Auto-renewal traps
    const autoRenewalElements = document.querySelectorAll('input[type="checkbox"], label');
    autoRenewalElements.forEach(element => {
        let labelText = element.textContent.toLowerCase();
        if (/auto-renew|watch now|buy premium|automatic renewal/i.test(labelText)) {
            element.addEventListener('click', () => {
                showPopup('Auto-Renewal Trap Detected: Automatic renewal may be applied without clear notice.');
            });
        }
    });

    // Account creation traps
    const accountCreationButtons = document.querySelectorAll('button, a');
    accountCreationButtons.forEach(button => {
        let buttonText = button.textContent.toLowerCase();
        if (/create account|register|get started|sign up/i.test(buttonText)) {
            button.addEventListener('click', () => {
                showPopup('Account Creation Trap Detected: Creating an account may lead to hidden traps.');
            });
        }
    });

    // Difficulty in unsubscribing or canceling
    const cancelButtons = document.querySelectorAll('button, a');
    cancelButtons.forEach(button => {
        let buttonText = button.textContent.toLowerCase();
        if (/unsubscribe|cancel/i.test(buttonText)) {
            button.addEventListener('click', () => {
                showPopup('Cancellation Trap Detected: The process may be intentionally difficult or hidden.');
            });
        }
    });
}

// Function to handle dynamically loaded content
function handleDynamicContent() {
    const observer = new MutationObserver(() => {
        detectRoachMotel();
    });

    observer.observe(document.body, { childList: true, subtree: true });

    // Recheck for traps after significant actions like button clicks
    document.body.addEventListener('click', (event) => {
        if (event.target.tagName === 'BUTTON' || event.target.tagName === 'A') {
            setTimeout(detectRoachMotel, 1000); // Delay to allow new content to load
        }
    });
}

// Initialize detection on page load
window.addEventListener('load', () => {
    detectRoachMotel();
    handleDynamicContent();
});
