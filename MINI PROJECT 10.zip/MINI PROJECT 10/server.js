// server.js
const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

app.use(express.static('public'));
app.use(bodyParser.json());

// Serve the HTML file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/roach1.html'));
});

// POST request to handle feedback submission
app.post('/submit-feedback', (req, res) => {
    const { userName, email, roachMotelDetected, feedbackMessage, url } = req.body;

    // Create a new feedback entry
    const feedback = {
        userName,
        email,
        roachMotelDetected,
        feedbackMessage,
        url,
        date: new Date().toLocaleString() // Store date and time
    };

    // Read existing feedbacks from the JSON file
    const feedbackFilePath = path.join(__dirname, 'feedbacks.json');
    let feedbacks = [];

    // Check if file exists and has content
    if (fs.existsSync(feedbackFilePath)) {
        const fileData = fs.readFileSync(feedbackFilePath, 'utf8');
        if (fileData) feedbacks = JSON.parse(fileData);
    }

    // Add new feedback to the array
    feedbacks.push(feedback);

    // Write the updated feedbacks array back to the file
    fs.writeFileSync(feedbackFilePath, JSON.stringify(feedbacks, null, 2));

    // Send response
    res.json({ message: 'Feedback saved successfully!' });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
